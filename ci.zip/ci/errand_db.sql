-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2020 at 03:11 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `errand_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `project_user_id` int(11) NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `project_body` text NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `project_user_id`, `project_name`, `project_body`, `date_created`) VALUES
(12, 7, 'Node JS', 'node js body', '2020-01-18 13:52:01'),
(13, 7, 'PHP Course', 'php coudse body', '2020-01-18 13:52:11'),
(16, 7, 'Java Course', 'java course body', '2020-01-19 04:32:09');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `task_name` varchar(255) NOT NULL,
  `task_body` text NOT NULL,
  `due_date` date NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `project_id`, `task_name`, `task_body`, `due_date`, `date_created`, `status`) VALUES
(1, 1, 'this i', 'sdlfjslf', '2020-01-16', '2020-01-18 13:47:09', 0),
(2, 10, 'thi php task name', 'php task body', '2020-01-15', '2020-01-18 13:49:27', 0),
(8, 11, 'php project ist the task wieth id 12', 'sdf', '2020-01-10', '2020-01-18 17:37:34', 0),
(9, 11, 'php project ist the task wieth id 12', 'sdf', '2020-01-10', '2020-01-18 17:40:18', 0),
(14, 16, 'java task 1 name', 'java task 1 body', '2020-01-10', '2020-01-19 12:50:37', 0),
(15, 16, 'java task 1 name', 'java task 1 body', '2020-01-10', '2020-01-19 12:50:55', 0),
(16, 16, 'java task 2 name', 'java task 2 body', '2020-01-11', '2020-01-19 12:51:27', 0),
(17, 16, 'java task 2 name', 'java task 2 body', '2020-01-11', '2020-01-19 12:58:29', 0),
(18, 16, 'java task 2 name', 'java task 2 body', '2020-01-11', '2020-01-19 12:58:47', 0),
(19, 16, 'java task 2 name', 'java task 2 body', '2020-01-11', '2020-01-19 12:58:59', 0),
(20, 13, 'Php course task 1 name', 'Php course task 1 body', '2020-01-11', '2020-01-19 13:00:13', 1),
(21, 13, 'Php course task 2 name', 'Php course task 2 name', '2020-01-15', '2020-01-19 13:01:33', 1),
(22, 13, 'Php course task 3 name', 'Php course task 3 name', '2020-01-27', '2020-01-19 13:03:17', 0),
(23, 13, 'Php course task 3 name', 'Php course task 3 name', '2020-01-27', '2020-01-19 13:03:26', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `first_name`, `last_name`, `email`, `register_date`) VALUES
(1, 'rico', '123', '', '', '', '2020-01-14 09:54:58'),
(3, 'puhupwas', 'no donyfyrtye is not giong to done', '', '', '', '2020-01-14 09:54:58'),
(4, 'puhupwasbind', '', 'Puhupwas', 'Bind', 'puhupwasbind301@gmail.com', '2020-01-14 15:11:35'),
(5, 'puhupwasbind', '', 'Puhupwas', 'Bind', 'puhupwasbind301@gmail.com', '2020-01-14 15:12:10'),
(6, 'neerajsharma', '$2y$12$/x8LxjDu/gufAVy.RaIM8.5Y9DcdEeiGWGr73b.1vAmQZHVkU1ER2', 'Neeraj', 'Sharma', 'neerajsharma@gmail.com', '2020-01-14 15:24:56'),
(7, 'surajsharma', '$2y$12$N97muKPQsL9n/7/Ui89fW.0Ju.lqL/ORM//n5LAqVSvKrP9SQJ0uy', 'suraj', 'sharma', 'suraj@gmail.com', '2020-01-14 15:37:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
