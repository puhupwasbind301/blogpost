<?php 

/**
 * 
 */
class Tasks extends CI_Controller
{
	
	public function display($task_id)
	{
		// video 112, this is for the fetching "project_name" for the task it belongs
		// first we need project_id to find project_name this task belong
		$data['project_id'] = $this->task_model->get_task_project_id($task_id);
		$data['project_name'] = $this->task_model->get_project_name($data['project_id']);
		// this model already created 



		$data['task'] = $this->task_model->get_task($task_id);

		$data['main_view'] = 'tasks/display';

		$this->load->view('layouts/main',$data);
		 

	}



	public function create($project_id){  // we need of $project_id to relate with tasks

		$this->form_validation->set_rules('task_name', 'Task Name', 'trim|required');
		$this->form_validation->set_rules('task_body', 'Task Body','trim|required');


		if($this->form_validation->run() == FALSE){

			$data['main_view'] = 'tasks/create_task';
			$this->load->view('layouts/main',$data);

		} else {

			$data = array(

					//'task_user_id' => $this->session->set_userdata('user_id'),

					'project_id' => $project_id, 
					'task_name' => $this->input->post('task_name'),
					'task_body' => $this->input->post('task_body'),
					'due_date' => $this->input->post('due_date')
					);

			if($this->task_model->task_create($data)){
				$this->session->set_flashdata('task_created','Your task has been Created');
				redirect('project/display/'.$project_id.''); // taking to the current spacific projects tasks
			}
		}



	}




	public function edit($task_id){  // we need of $project_id to relate with tasks

		$this->form_validation->set_rules('task_name', 'task Name', 'trim|required');
		$this->form_validation->set_rules('task_body', 'task Description', 'trim|required');


		if($this->form_validation->run() == FALSE) {


			$data['project_id'] = $this->task_model->get_task_project_id($task_id);

			$data['project_name'] = $this->task_model->get_project_name($data['project_id']);

			$data['the_task'] = $this->task_model->get_task_project_data($task_id);




			$data['main_view'] = 'tasks/edit_task';
			$this->load->view('layouts/main', $data);



		} else {


			$project_id = $this->task_model->get_task_project_id($task_id);

			$data = array(

				'project_id' => $project_id,
				'task_name' => $this->input->post('task_name'),
				'task_body' => $this->input->post('task_body'),
				'due_date' => $this->input->post('due_date')
				
				);


			if($this->task_model->edit_task($task_id, $data)) {

				$this->session->set_flashdata('task_updated', 'Your task has been updated');

				redirect("project/index");


			}



		}

	}


	public function delete($project_id,$task_id){ // this project id is set to redirect the task display of specific project, this $project id is coming from view tasks-> display 

		$this->task_model->delete_task($task_id);
		$this->session->set_flashdata('task_deleted', 'Your Task has been deleted');
		redirect('project/display/'.$project_id.'');



	}



	public function mark_complete($task_id){ // first set a link for this method in tasks/display,

		if($this->task_model->mark_task_complete($task_id)){  // then call to this model mark_complete()
			
			$project_id = $this->task_model->get_task_project_id($task_id); // this model is already created look above its first contrller
			$this->session->set_flashdata('mark_done','Task has been completed directly by clicking');

			redirect('project/display/'.$project_id.'');

		}


	}




	public function mark_incomplete($task_id){

		if($this->task_model->mark_task_incomplete($task_id)){
			
			$project_id = $this->task_model->get_task_project_id($task_id); // this model is already created look above its first contrller
			$this->session->set_flashdata('mark_undone','Task has been incompleted directly by clicking');

			redirect('project/display/'.$project_id.'');

		}
	
	}





}

 ?>