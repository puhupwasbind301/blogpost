<?php

class Project extends CI_Controller {

public function __construct(){
parent::__construct();

if(!$this->session->userdata('logged_in')){

	$this->session->set_flashdata('no_access','Sorry You are NOT allowed or NOT Logged in to Projects Views');
	redirect('home/index');
	}

}	

	public function index()
	{

$data['projects'] = $this->project_model->get_projects();    //This is get_productssssssssssssss method

		//$this->load->view('welcome_message');
	$data['main_view'] = 'projects/index';

		$this->load->view('layouts/main',$data);
	}


	public function display($project_id){   //this project id is receiveing the project_id while clicking on the prject available at project view page like PHP

		$data['completed_tasks'] = $this->project_model->get_project_tasks($project_id,true);  //this model is used for checking tasks active or disactive
		$data['not_completed_tasks'] = $this->project_model->get_project_tasks($project_id,false);

		$data['project_data'] = $this->project_model->get_project($project_id);    //This is get_product method

		$data['main_view'] = 'projects/display';   // here is the project name i.e projects then file name i.e display
		$this->load->view('layouts/main',$data);

	}


	public function create(){

		$this->form_validation->set_rules('project_name', 'Project Name', 'trim|required');
		$this->form_validation->set_rules('project_body', 'Project Body','trim|required');


		if($this->form_validation->run() == FALSE){

			$data['main_view'] = 'projects/create_project';
			$this->load->view('layouts/main',$data);

		} else {

			$data = array(

					'project_user_id' => $this->session->userdata('user_id'),
					'project_name' => $this->input->post('project_name'),
					'project_body' => $this->input->post('project_body')
					);

			if($this->project_model->create_project($data)){
				$this->session->set_flashdata('project_created','Your Project has been Created');
				redirect('project/index');
			}
		}



	}

		public function edit($project_id){

		$this->form_validation->set_rules('project_name', 'Project Name', 'trim|required');
		$this->form_validation->set_rules('project_body', 'Project Body','trim|required');


		if($this->form_validation->run() == FALSE){ 

			$data['project_data']	 =  $this->project_model->get_project_info($project_id);
			$data['main_view'] = 'projects/edit_project';
			$this->load->view('layouts/main',$data);

		} else {

			$data = array(

					'project_user_id' => $this->session->userdata('user_id'),
					'project_name' => $this->input->post('project_name'),
					'project_body' => $this->input->post('project_body')
					);

			if($this->project_model->edit_project($project_id,$data)){
				$this->session->set_flashdata('project_updated','Your Project has been Updated');
				redirect('project/index');
			}
		}



	}

	public function delete($project_id){

		$this->project_model->delete_project_tasks($project_id); // deleting specific project with all of its tasks, tasks shouldn't be there in the database;

		if($this->project_model->delete_project($project_id)){
		$this->session->set_flashdata('project_deleted','Your Project has been Deleted');
		redirect('project/index');
		}
	}



	
}

?>
 