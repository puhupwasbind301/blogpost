<?php

class Users extends CI_Controller {

 // public function show($user_id){
// //user modal is autoloaded in config autoload
//  	//$this->load->modal('users_modal');

//  	//$result['abcs'] = $this->user_model->get_users(1);
//    	$result['abcs'] = $this->user_model->get_users($user_id,'rico');

//  		//$data['welcome'] = "this is the message from controller";


//  	$this->load->view('user_view',$result);



//  	// foreach ($result as $object) {

//  	// 	echo $object->id.'<br>';
//  	// 	echo $object->username.'<br>';
//  	// }

// 	 }


//  public function insert(){
//  	$username = 'puhupwas';
//  	$password = 'no password set yet';

//  	$this->user_model->create_user([

//  		'username' => $username,
//  		'password' => $password
//  	]);
 
//  	}




// public function update(){
// 	$id = '2';

//  	$username = 'puhupwas unlimited';
//  	$password = 'not giong to done';

//  	$this->user_model->update_user([

//  		'username' => $username,
//  		'password' => $password
//  	], $id);
 	
//  	}



// public function delete(){
// 			$id = '2';
//  		$this->user_model->delete_user($id);
//  }


public function register(){
		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required|min_length[3]');
		$this->form_validation->set_rules('last_name', 'First Name', 'trim|required|min_length[3]');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|min_length[3]');
		$this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[3]');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[3]');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|min_length[3]|matches[password]');


			if($this->form_validation->run() == FALSE){

				//echo validation_errors();

			 $data['main_view'] = 'users/register_view' ;
			 $this->load->view('layouts/main' ,$data);
			}
			else
			{
					if($this->user_model->create_user()){
						$this->session->set_flashdata('user_registerd','New User has been registerd!');
						redirect('home/index');
					} else {

					}
			}


}	



public function login(){

	//echo $_POST['username']; old way of doing this to get data
	//echo $_POST['password'];

	//echo $this->input->post('username');
//$this->load->helper(array('from','url'));
	//$this->load->helper('form');
//$this->load->library('form_validation');

		$this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[3]');
		// $this->form_validation->set_rules(
  //       'username', 'Username',
  //       'required|min_length[5]|max_length[12]|is_unique[users.username]',
  //       array(
  //               'required'      => 'You have not provided %s.',
  //               'is_unique'     => 'This %s already exists.'
  //       )
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[3]');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 
			'trim|required|min_length[3]|matches[password]');
		
		if($this->form_validation->run() == FALSE) {

			 //echo form_error('options[color][]'); 

			//echo 'jhgjjpuhupwas';

	
			//echo validation_errors(); 

			$data= array(
				'errors' => validation_errors() 
);
           //ECHO $data;
			
			//$data = $data['errors'];
			//$data['main_view'] = 'home_view';
			//$this->load->view('users/login_view',$data);

			$this->session->set_flashdata($data);
			//$this->session->set_flashdata('errors',validation_errors());
			redirect('home');
			
			}
			else
			{
					//	echo 'LOgin Successfully<br>';


				$username = $this->input->post('username');
				$password = $this->input->post('password');

				$user_id = $this->user_model->login_user($username,$password); 
				  //echo validation_errors('<div class="alert alert-danger">', '</div>'); 

				//echo $user_id;

				if($user_id){

					$user_data = array(

						'user_id'  =>  $user_id,
						'username' => $username,
						'logged_in' => true


						);

					$this->session->set_userdata($user_data);
					 $this->session->set_flashdata('login_success','You are now Login');
					//$_SESSION['login_success','hiisdf']
					$data['main_view'] = 'admin_view';

					$this->load->view('layouts/main',$data);

					//redirect('home/index');

				} else {
					 $this->session->set_flashdata('login_failed','Not Login');
					redirect('home/index');
				}

			}
			
			//$this->load->view('login_view');

		}

	public function logout(){

		$this->session->sess_destroy();
		redirect('home/index');
			}

}


?>