<!-- 
<form action="<?php // echo base_url()?>users/login" method="post">
	<div class="form-group">
		<label>Name</label>
		<input type="text" name="uaername" class="form-control" value="<?php // echo set_value('username');?>">
		<small class="text-danger"><?= // form_error('username')?></small>
	</div>

	<div class="form-group">
		<label>pssword</label>
		<input type="password" name="password" class="form-control">
		<small class="text-danger"><?= // form_error('password')?></small>
	</div>

	<div class="form-group">
		<label>Confirm Password</label>
		<input type="password" name="confirm_password" class="form-control">
		<small class="text-danger"><?= //form_error('confirm_password')?></small>
	</div>

	<div class="form-group">
		<button class="btn btn-primary" type="submit">Login</button>
	</div>

</form> -->