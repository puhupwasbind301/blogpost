<!DOCTYPE html>
<html>
<head>
	<title> User view</title>
</head>
<body>
<h1>
	<?php 

//echo $welcome;


//echo $abcs;

 	foreach ($abcs as $object) {

 		//echo $object->id.'<br>';
 		echo $object->username.'<br>';
 	}




	 ?>



</h1>

</body>
</html>