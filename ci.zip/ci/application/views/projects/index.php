<h1>Project</h1>
<p class="bg-success">

		<?php if($this->session->flashdata('project_created')): ?>

		<?php echo  $this->session->flashdata('project_created');  ?>
	<?php endif; ?>


	<?php if($this->session->flashdata('project_updated')): ?>

		<?php echo  $this->session->flashdata('project_updated');  ?>
	<?php endif; ?>



	<?php if($this->session->flashdata('task_updated')): ?>

		<?php echo  $this->session->flashdata('task_updated');  ?>
	<?php endif; ?>

</p>
<p class="bg-danger">

	<?php if($this->session->flashdata('project_deleted')): ?>

		<?php echo  $this->session->flashdata('project_deleted');  ?>
	<?php endif; ?>

	

</p>

<a class="btn btn-primary pull-right" href="<?php echo base_url(); ?>project/create">Created Project</a>
<table class="table table-hover">
	<thead>
		<tr>
			<th>
				Project Name
			</th>
			<th>
				Project Body
			</th>
			<th>
				Action
			</th>
		</tr>

	</thead>
	<tbody>
		
		<?php 

			foreach($projects as $project) :
				echo '<tr>';
				echo '<td><a href="'.base_url().'project/display/'.$project->id.'">'.$project->project_name.'</a></td>';    // here is the project as Controller and display as method
				echo '<td>'.$project->project_body.'</td>';

				echo '    <td><a class="btn btn-primary"  href="   '   .base_url().'project/delete/'.$project->id.'"><span class="glyphicon glyphicon-remove"></span></a></td>';
				echo '</tr>';
		    endforeach;	

		 ?>

	</tbody>


</table>