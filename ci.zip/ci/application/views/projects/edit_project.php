<h1>Edit Project</h1>

<?php $attributes = array('id'=>'project_form', 'class'=> 'form_horizontal'); ?>

<?php echo validation_errors('<p class="bg-danger" style="background:orange">'); ?>

<?php //echo $project_data->id; ?>

<?php echo form_open('project/edit/'. $project_data->id .'' ,$attributes);?>


<div class="form-group">

<?php echo form_label('Project Name'); ?>
<?php

$data = array(

	'class' => 'form-control',
	'name' => 'project_name',
	'placeholder' => 'Enter Project Name',
	'value' => $project_data->project_name

	);


 ?>
<?php echo form_input($data); ?>




<?php echo form_label('Project Description'); ?>
<?php

$data = array(

	'class' => 'form-control',
	'name' => 'project_body',
	'placeholder' => 'Enter Your Project Description',
	'value' => $project_data->project_body
	);
 ?>
<?php echo form_textarea($data); ?>




<div class="form-group">
	

<?php

$data = array(

	'class' => 'btn btn-primary',
	'name' => 'submit',
	'value' => 'Updated'

	);


 ?>



<?php echo form_submit($data); ?>



</divx>

<?php echo form_close();?>
