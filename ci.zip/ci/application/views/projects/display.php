<div class="col-xs-9">

<!-- 108 video  mark comeplete or incomplete messege display-->
<p class="bg-success text-center">
<!-- setting a messege for Marks complete or incomplete by clicking link, from the task controller -->
		<?php if($this->session->userdata('mark_done')): ?>

		<?php echo  $this->session->flashdata('mark_done');  ?> 
		<?php endif; ?>

<!-- after refreshing flashdata removes its  message -->
<!-- after refreshing userdata doesn't removes its  message -->


		<?php if($this->session->flashdata('mark_undone')): ?>

		<?php echo  $this->session->flashdata('mark_undone');  ?>
	<?php endif; ?>

</p>





<h1>Project Name: <?php echo $project_data->project_name; ?></h1>
<p>Date Created: <?php echo $project_data->date_created; ?></p>

<div class="panel panel-primary">
		<div class="panel-heading">
		<h3>Description</h3>
		</div>
		<div class="panel-body">
			<?php echo $project_data->project_body; ?>
		</div>
</div>


<div class="panel panel-primary">
		<div class="panel-heading">
		<h3>Active Tasks</h3>
		</div>
		<div class="panel-body">

<ul>
<?php 
//createing tasks active or disactive by status by default 0 in DB i.e tasks is pending
if($completed_tasks): 

	foreach($completed_tasks as $task):
		?>
		<li>
		<a href="<?php echo base_url(); ?>/tasks/display/<?php echo $task->task_id ?>">  <!-- here the task_id is used instead of  id of tasks to defrentiate in project model in get_project_tasks(); -->
		<?php  echo $task->task_name;  ?>
		</a>
		</li>

		<?php
	endforeach;
else:
	echo '<b>There is no Tasks Available</b>';
endif;	

 ?>
</ul>

		</div>
</div>



<div class="panel panel-primary">
		<div class="panel-heading">
		<h3>Tasks Completed</h3>
		</div>
		<div class="panel-body">
<ul>
<?php 
//createing tasks active or disactive by status by default 0 in DB i.e tasks is pending
if($not_completed_tasks): 

	foreach($not_completed_tasks as $task):
		?>
		<li>
		<a href="<?php echo base_url(); ?>/tasks/display/<?php echo $task->task_id ?>">  <!-- here the task_id is used instead of  id of tasks to defrentiate in project model in get_project_tasks(); -->
		<?php  echo $task->task_name;  ?>
		</a>
		</li>

		<?php
	endforeach;
else:
	echo '<b>There is no Tasks Pending.</b>';
endif;	

 ?>
</ul>
		</div><!-- panel body ends -->
	</div><!-- panel  ends -->


 </div> <!-- col-xs-9  ends -->

<div class="col-xs-3 pull-right">
	<h2>Project Actions</h2>
			<ul class="list-group">
			 		
			<li class="list-group-item btn btn-danger"><a href="<?php echo base_url(); ?>tasks/create/<?php echo $project_data->id; ?>">Create Tasks</a></li>
			<li class="list-group-item btn btn-primary"><a href="<?php echo base_url(); ?>project/edit/<?php echo $project_data->id; ?>">Edit</a></li>
			<li class="list-group-item btn btn-primary"><a href="<?php echo base_url(); ?>project/Delete/<?php echo $project_data->id; ?>">Delete</a></li>


			</ul>

</div>