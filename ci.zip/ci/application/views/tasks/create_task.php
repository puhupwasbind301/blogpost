<h1>Create task</h1>

<?php $attributes = array('id'=>'task_form', 'class'=> 'form_horizontal'); ?>

<?php echo validation_errors('<p class="bg-danger" style="background:orange">'); ?>



<?php echo form_open('tasks/create/'.$this->uri->segment(3).'', $attributes);?>


<div class="form-group">

<?php echo form_label('Task Name'); ?>
<?php

$data = array(

	'class' => 'form-control',
	'name' => 'task_name',
	'placeholder' => 'Enter task Name'

	);


 ?>
<?php echo form_input($data); ?>




<?php echo form_label('Task Description'); ?>
<?php

$data = array(

	'class' => 'form-control',
	'name' => 'task_body',
	'placeholder' => 'Enter Your task Description'

	);
 ?>
<?php echo form_textarea($data); ?>



<?php echo form_label('Task Tue Date'); ?>
<?php

$data = array(

	'class' => 'form-control',
	'name' => 'due_date',
	'type' => 'date'

	);
 ?>
<?php echo form_input($data); ?>




<div class="form-group">
	

<?php

$data = array(

	'class' => 'btn btn-primary',
	'name' => 'submit',
	'value' => 'Create task'

	);


 ?>



<?php echo form_submit($data); ?>



</divx>

<?php echo form_close();?>
