<!-- using tasks controller Line 14 $data['project_name'], here project_name as $project_name variable to display project name -->

<div class="col-xs-9">
<h1><?php echo $task->task_name; ?></h1>  
<p><b>Project Name:</b> <?php echo $project_name; ?></p>

<p><b>Date Created:</b> <?php echo $task->date_created; ?></p>	
<p><b>Due on:</b> <?php echo $task->due_date; ?></p>

<h3>Description</h3>	
<p class="task-description">
	<?php echo $task->task_body; ?>
</p>

</div>


<!-- <?php //echo $task->task_name; ?> -->


<!-- 
<table class="table table-hover">
					<thead>
						<tr>
							<th>
								Task Name
							</th>
							<th>
								Task Body
							</th>
							<th>
								Current Date
							</th>
							
						</tr>

					</thead>
					
<! This is start of the  body for nice styling is below in div col-xs-3 -->
					<!-- COUSTION:ALL PART OF BODY IS COMMENTED  -->
					<!-- EVEN ECHO IS COMMENTED IT WONT WORK -->
					<!--		<tbody>
						
						<?php 

							
								echo '<tr>';
								echo '<td>
										<div class="task_name">'
										.$task->task_name.
										'</div>

										 <div class="task_action">
											<a href="   '.base_url().'tasks/edit/'.$task->id.'  ">Edit</a>
											<a href="   '.base_url().'tasks/delete/'.$task->project_id.'/'.$task->id.'  ">Delete</a>
									     </div>	


									  </td>'; 
									  	// $task->project_id in delete it specifies specific task , sending to tasks controller detete() as parameter to redirect specific project
									     // here is the task as Controller and display as method
									//ABOVE php coding is uncommented

									  

								
								echo '<td>'.$task->task_body.'</td>'; //here $task is not a table name it is row returned data in controller i.e $data['task']  , task is used as variable $task
								echo '<td>'.$task->date_created.'</td>';

							//	echo '    <td><a href="  '   .base_url().   'tasks ">View</a></td>  ';

								echo '<td><a href="  '.base_url().'tasks/mark_complete/'.$task->id.'">Mark Completed</a></td>'; // this is used  to make it task complete directly by clicking , mark_complete() controller
								echo '<td><a href="  '.base_url().'tasks/mark_incomplete/'.$task->id.'">Mark Incompleted</td>';
								
								echo '</tr>';
						    

						 ?>

					</tbody>
				</table> 
<! /This is end of tABLE commented to make it look better styling is below for this body -->
				
<!--type Lorem then tab to get paragraph-->




<div class="col-xs-3 pull-right">
	<h2>Task Actions</h2>
			<ul class="list-group">
			 	<?php 
			echo '<li class="list-group-item btn btn-primary"><a href="   '.base_url().'tasks/edit/'.$task->id.'  ">Edit</a></li>';
			echo '<li class="list-group-item btn btn-danger"><a href="   '.base_url().'tasks/delete/'.$task->project_id.'/'.$task->id.'  ">Delete</a></li>';
			echo '<li class="list-group-item btn btn-primary"><a href="  '.base_url().'tasks/mark_complete/'.$task->id.'">Mark Completed</a></li>';
			echo '<li class="list-group-item btn btn-primary"><a href="  '.base_url().'tasks/mark_incomplete/'.$task->id.'">Mark Incompleted</a></li>';

			 ?>	
			</ul>

</div>			