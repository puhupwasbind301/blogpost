<h1>
<p class="bg-success">

	

	<?php if($this->session->flashdata('login_success')): ?>

		<?php echo  $this->session->flashdata('login_success');  ?>
	<?php endif; ?>



	<?php if($this->session->flashdata('user_registerd')): ?>

		<?php echo  $this->session->flashdata('user_registerd');  ?>
	<?php endif; ?>

</p>

<p class="bg-danger">



	<?php if($this->session->flashdata('login_failed')): ?>

		<?php echo  $this->session->flashdata('login_failed');  ?>
	<?php endif; ?>


	<?php if($this->session->flashdata('no_access')): ?>

		<?php echo  $this->session->flashdata('no_access');  ?>
	<?php endif; ?>


</p>

</h1>

<div class="jumbotron">
<h3 class="text-center">Welcome to the Codignater Application</h3>
	

</div>

		
<?php if(isset($projects)): ?>
	<div class="panel panel-primary">
		<div class="panel-heading">
		<h3>Projects..</h3>
		</div>
		<div class="panel-body">

				<table class="table table-hover">
				<!-- 	<thead>
						<tr>
							<th>
								Project Name
							</th>
							<th>
								Project Body
							</th>
							<th>
								Action
							</th>
						</tr>

					</thead> -->
					<tbody>
						
						<?php 

							foreach($projects as $project) :
								echo '<tr>';
								echo '<td>'.$project->project_name.'</td>';    // here is the project as Controller and display as method
								echo '<td>'.$project->project_body.'</td>';

								echo '    <td><a href="  '   .base_url().   'project/display/'.$project->id.' ">View</a></td>  ';
								echo '</tr>';
						    endforeach;	

						 ?>

					</tbody>


				</table>
		</div>
	</div>
<?php endif; ?>



<!-- video 111 getting all tasks of specific user by project_user_id -->

<?php if(isset($tasks)): ?>


	<div class="panel panel-primary">
		<div class="panel-heading">
		<h3>Tasks..</h3>
		</div>
		<div class="panel-body">		
				<table class="table table-hover">
					<thead>
						<tr>
							<th>
								Task Name
							</th>
							<th>
								Task Body
							</th>
							<th>
								Action
							</th>
						</tr>

					</thead>
					<tbody>
						
						<?php 

							foreach($tasks as $task) :
								echo '<tr>';
								echo '<td>'.$task->task_name.'</td>';    // here is the task as Controller and display as method
								echo '<td>'.$task->task_body.'</td>';

								echo '    <td><a href="  '   .base_url().   'tasks/display/'.$task->id.' ">View</a></td>  ';
								echo '</tr>';
						    endforeach;	

						 ?>

					</tbody>


				</table>
		</div>
	</div>
<?php endif; ?>



